import React, { useMemo, useState } from 'react';
import { ThreatAnalysis } from '../types';

interface AttackHeatmapProps {
  analyzedLogs: Record<string, ThreatAnalysis>;
  theme: 'dark' | 'light';
}

// ── MITRE ATT&CK Tactics (Enterprise, ordered) ───────────────────────────────
const TACTICS: { id: string; name: string; short: string }[] = [
  { id: 'TA0043', name: 'Reconnaissance',        short: 'Recon'    },
  { id: 'TA0042', name: 'Resource Development',  short: 'Res Dev'  },
  { id: 'TA0001', name: 'Initial Access',        short: 'Init Acc' },
  { id: 'TA0002', name: 'Execution',             short: 'Exec'     },
  { id: 'TA0003', name: 'Persistence',           short: 'Persist'  },
  { id: 'TA0004', name: 'Privilege Escalation',  short: 'Priv Esc' },
  { id: 'TA0005', name: 'Defense Evasion',       short: 'Def Eva'  },
  { id: 'TA0006', name: 'Credential Access',     short: 'Cred Acc' },
  { id: 'TA0007', name: 'Discovery',             short: 'Discov'   },
  { id: 'TA0008', name: 'Lateral Movement',      short: 'Lat Mov'  },
  { id: 'TA0009', name: 'Collection',            short: 'Collect'  },
  { id: 'TA0011', name: 'Command & Control',     short: 'C2'       },
  { id: 'TA0010', name: 'Exfiltration',          short: 'Exfil'    },
  { id: 'TA0040', name: 'Impact',                short: 'Impact'   },
];

// Map common technique IDs to their parent tactic
const TECHNIQUE_TO_TACTIC: Record<string, string> = {
  // Reconnaissance
  'T1595': 'TA0043', 'T1592': 'TA0043', 'T1589': 'TA0043', 'T1590': 'TA0043',
  'T1591': 'TA0043', 'T1598': 'TA0043', 'T1597': 'TA0043', 'T1596': 'TA0043',
  'T1593': 'TA0043', 'T1594': 'TA0043',
  // Initial Access
  'T1190': 'TA0001', 'T1133': 'TA0001', 'T1078': 'TA0001', 'T1566': 'TA0001',
  'T1091': 'TA0001', 'T1200': 'TA0001', 'T1195': 'TA0001', 'T1199': 'TA0001',
  // Execution
  'T1059': 'TA0002', 'T1053': 'TA0002', 'T1072': 'TA0002', 'T1569': 'TA0002',
  'T1106': 'TA0002', 'T1129': 'TA0002', 'T1203': 'TA0002', 'T1204': 'TA0002',
  // Persistence
  'T1098': 'TA0003', 'T1547': 'TA0003', 'T1037': 'TA0003', 'T1543': 'TA0003',
  'T1136': 'TA0003', 'T1197': 'TA0003', 'T1176': 'TA0003', 'T1554': 'TA0003',
  // Privilege Escalation
  'T1548': 'TA0004', 'T1134': 'TA0004', 'T1068': 'TA0004', 'T1484': 'TA0004',
  'T1611': 'TA0004', 'T1055': 'TA0004',
  // Defense Evasion
  'T1140': 'TA0005', 'T1574': 'TA0005', 'T1036': 'TA0005', 'T1556': 'TA0005',
  'T1562': 'TA0005', 'T1070': 'TA0005', 'T1202': 'TA0005', 'T1112': 'TA0005',
  // Credential Access
  'T1110': 'TA0006', 'T1555': 'TA0006', 'T1212': 'TA0006', 'T1187': 'TA0006',
  'T1606': 'TA0006', 'T1056': 'TA0006', 'T1557': 'TA0006', 'T1528': 'TA0006',
  'T1539': 'TA0006', 'T1558': 'TA0006',
  // Discovery
  'T1087': 'TA0007', 'T1010': 'TA0007', 'T1217': 'TA0007', 'T1580': 'TA0007',
  'T1046': 'TA0007', 'T1135': 'TA0007', 'T1040': 'TA0007', 'T1201': 'TA0007',
  'T1120': 'TA0007', 'T1069': 'TA0007', 'T1057': 'TA0007', 'T1012': 'TA0007',
  'T1518': 'TA0007', 'T1082': 'TA0007', 'T1016': 'TA0007', 'T1049': 'TA0007',
  'T1033': 'TA0007', 'T1007': 'TA0007', 'T1124': 'TA0007',
  // Lateral Movement
  'T1021': 'TA0008', 'T1091': 'TA0008', 'T1210': 'TA0008', 'T1534': 'TA0008',
  'T1570': 'TA0008', 'T1563': 'TA0008', 'T1080': 'TA0008', 'T1550': 'TA0008',
  // Collection
  'T1560': 'TA0009', 'T1123': 'TA0009', 'T1119': 'TA0009', 'T1185': 'TA0009',
  'T1115': 'TA0009', 'T1213': 'TA0009', 'T1005': 'TA0009', 'T1039': 'TA0009',
  'T1025': 'TA0009', 'T1074': 'TA0009', 'T1114': 'TA0009', 'T1056': 'TA0009',
  // C2
  'T1071': 'TA0011', 'T1092': 'TA0011', 'T1132': 'TA0011', 'T1001': 'TA0011',
  'T1568': 'TA0011', 'T1573': 'TA0011', 'T1008': 'TA0011', 'T1105': 'TA0011',
  'T1104': 'TA0011', 'T1095': 'TA0011', 'T1571': 'TA0011', 'T1572': 'TA0011',
  'T1090': 'TA0011', 'T1219': 'TA0011', 'T1205': 'TA0011', 'T1102': 'TA0011',
  // Exfiltration
  'T1020': 'TA0010', 'T1030': 'TA0010', 'T1048': 'TA0010', 'T1041': 'TA0010',
  'T1011': 'TA0010', 'T1052': 'TA0010', 'T1567': 'TA0010', 'T1029': 'TA0010',
  // Impact
  'T1531': 'TA0040', 'T1485': 'TA0040', 'T1486': 'TA0040', 'T1491': 'TA0040',
  'T1561': 'TA0040', 'T1499': 'TA0040', 'T1495': 'TA0040', 'T1490': 'TA0040',
  'T1498': 'TA0040', 'T1496': 'TA0040', 'T1489': 'TA0040', 'T1529': 'TA0040',
};

// Keyword-based tactic inference for techniques Gemini names but don't have exact IDs
const TACTIC_KEYWORDS: { keywords: string[]; tacticId: string }[] = [
  { keywords: ['reconnaissance', 'scan', 'probe', 'enumerat'],          tacticId: 'TA0043' },
  { keywords: ['initial access', 'exploit', 'injection', 'phish'],      tacticId: 'TA0001' },
  { keywords: ['execution', 'script', 'command'],                        tacticId: 'TA0002' },
  { keywords: ['persist', 'startup', 'scheduled'],                      tacticId: 'TA0003' },
  { keywords: ['privilege', 'escalat', 'root', 'admin'],                tacticId: 'TA0004' },
  { keywords: ['evasion', 'obfuscat', 'bypass', 'disable'],             tacticId: 'TA0005' },
  { keywords: ['credential', 'brute', 'password', 'hash', 'kerberos'],  tacticId: 'TA0006' },
  { keywords: ['discovery', 'port scan', 'network scan'],               tacticId: 'TA0007' },
  { keywords: ['lateral', 'rdp', 'smb', 'pass-the'],                   tacticId: 'TA0008' },
  { keywords: ['collect', 'keylog', 'screenshot', 'clipboard'],         tacticId: 'TA0009' },
  { keywords: ['command and control', 'c2', 'c&c', 'beacon', 'tor'],    tacticId: 'TA0011' },
  { keywords: ['exfiltrat', 'data theft', 'dns tunnel'],                tacticId: 'TA0010' },
  { keywords: ['impact', 'ransomware', 'wiper', 'dos', 'disrupt'],      tacticId: 'TA0040' },
];

function inferTacticFromTTP(technique: string, id: string): string | null {
  // Exact technique ID match (strip subtechnique suffix, e.g. T1021.001 → T1021)
  const baseId = id.split('.')[0].toUpperCase();
  if (TECHNIQUE_TO_TACTIC[baseId]) return TECHNIQUE_TO_TACTIC[baseId];

  // Keyword match on technique name
  const lower = technique.toLowerCase();
  for (const { keywords, tacticId } of TACTIC_KEYWORDS) {
    if (keywords.some(k => lower.includes(k))) return tacticId;
  }
  return null;
}

// ── Heat colour helper ────────────────────────────────────────────────────────
function heatColor(count: number, max: number, dark: boolean): string {
  if (count === 0) return dark ? '#1a1f2e' : '#f3f4f6';
  const intensity = max > 0 ? count / max : 0;
  if (intensity >= 0.75) return dark ? '#dc2626' : '#ef4444'; // red
  if (intensity >= 0.50) return dark ? '#ea580c' : '#f97316'; // orange
  if (intensity >= 0.25) return dark ? '#ca8a04' : '#eab308'; // amber
  return dark ? '#166534' : '#22c55e';                         // green
}

function textColor(count: number, max: number): string {
  if (count === 0) return '#6b7280';
  const intensity = max > 0 ? count / max : 0;
  return intensity >= 0.25 ? '#ffffff' : '#1f2937';
}

// ── Component ─────────────────────────────────────────────────────────────────
const AttackHeatmap: React.FC<AttackHeatmapProps> = ({ analyzedLogs, theme }) => {
  const [selectedTactic, setSelectedTactic] = useState<string | null>(null);
  const dark = theme === 'dark';

  // Build tactic → { count, techniques[] } from all analyzed logs
  const tacticData = useMemo(() => {
    const counts: Record<string, number> = {};
    const techniques: Record<string, { name: string; id: string; logCount: number }[]> = {};

    TACTICS.forEach(t => { counts[t.id] = 0; techniques[t.id] = []; });

    Object.values(analyzedLogs).forEach(analysis => {
      analysis.threatActorDNA?.ttps?.forEach(ttp => {
        const tacticId = inferTacticFromTTP(ttp.technique, ttp.id);
        if (!tacticId) return;

        counts[tacticId] = (counts[tacticId] || 0) + 1;

        const existing = techniques[tacticId].find(t => t.id === ttp.id);
        if (existing) {
          existing.logCount++;
        } else {
          techniques[tacticId].push({ name: ttp.technique, id: ttp.id, logCount: 1 });
        }
      });
    });

    return { counts, techniques };
  }, [analyzedLogs]);

  const maxCount = Math.max(1, ...Object.values(tacticData.counts));
  const totalTTPs = Object.values(tacticData.counts).reduce((a, b) => a + b, 0);
  const activeTactics = Object.values(tacticData.counts).filter(c => c > 0).length;

  const selectedTechniques = selectedTactic
    ? (tacticData.techniques[selectedTactic] || []).sort((a, b) => b.logCount - a.logCount)
    : [];

  const noData = Object.keys(analyzedLogs).length === 0;

  return (
    <div className="bg-white dark:bg-black border border-gray-200 dark:border-gray-800 rounded-lg p-5 space-y-5">

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-blue-600 dark:text-blue-400">
            MITRE ATT&CK® Coverage
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
            Tactics detected across analyzed threats · Click a tactic for techniques
          </p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-black dark:text-white">{activeTactics}</div>
          <div className="text-xs text-gray-500 dark:text-gray-400">active tactics</div>
        </div>
      </div>

      {/* Heat grid */}
      <div className="grid grid-cols-7 gap-1.5">
        {TACTICS.map(tactic => {
          const count = tacticData.counts[tactic.id] || 0;
          const bg = heatColor(count, maxCount, dark);
          const fg = textColor(count, maxCount);
          const isSelected = selectedTactic === tactic.id;
          return (
            <button
              key={tactic.id}
              onClick={() => setSelectedTactic(isSelected ? null : tactic.id)}
              style={{ backgroundColor: bg, color: fg }}
              className={`rounded-md p-2 text-center transition-all duration-200 border-2 ${
                isSelected
                  ? 'border-blue-400 scale-105 shadow-lg'
                  : 'border-transparent hover:border-gray-300 dark:hover:border-gray-600'
              }`}
              title={`${tactic.name}: ${count} TTP${count !== 1 ? 's' : ''} detected`}
            >
              <div className="text-xs font-bold leading-tight">{count}</div>
              <div className="text-[10px] leading-tight mt-0.5 font-medium opacity-90">
                {tactic.short}
              </div>
            </button>
          );
        })}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
        <span>Coverage:</span>
        {[
          { label: 'None',     bg: dark ? '#1a1f2e' : '#f3f4f6', border: true },
          { label: 'Low',      bg: dark ? '#166534' : '#22c55e' },
          { label: 'Medium',   bg: dark ? '#ca8a04' : '#eab308' },
          { label: 'High',     bg: dark ? '#ea580c' : '#f97316' },
          { label: 'Critical', bg: dark ? '#dc2626' : '#ef4444' },
        ].map(({ label, bg, border }) => (
          <span key={label} className="flex items-center gap-1">
            <span
              className={`inline-block w-3 h-3 rounded-sm ${border ? 'border border-gray-300 dark:border-gray-700' : ''}`}
              style={{ backgroundColor: bg }}
            />
            {label}
          </span>
        ))}
      </div>

      {/* No data state */}
      {noData && (
        <div className="rounded-lg bg-gray-50 dark:bg-gray-900 border border-dashed border-gray-300 dark:border-gray-700 p-6 text-center">
          <div className="text-2xl mb-2">🎯</div>
          <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
            No threats analyzed yet
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-500 mt-1">
            Select a log from the feed and click Analyze to start mapping ATT&CK techniques
          </div>
        </div>
      )}

      {/* Selected tactic drill-down */}
      {selectedTactic && (
        <div className="rounded-lg bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                {TACTICS.find(t => t.id === selectedTactic)?.id}
              </div>
              <div className="text-sm font-semibold text-black dark:text-white">
                {TACTICS.find(t => t.id === selectedTactic)?.name}
              </div>
            </div>
            <button
              onClick={() => setSelectedTactic(null)}
              className="text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              ✕ close
            </button>
          </div>

          {selectedTechniques.length === 0 ? (
            <p className="text-xs text-gray-500 dark:text-gray-400 italic">
              No techniques detected under this tactic yet.
            </p>
          ) : (
            <div className="space-y-1.5">
              {selectedTechniques.map(tech => (
                <div
                  key={tech.id}
                  className="flex items-center justify-between bg-white dark:bg-gray-800 rounded-md px-3 py-2 border border-gray-200 dark:border-gray-700"
                >
                  <div>
                    <span className="text-xs font-mono text-blue-600 dark:text-blue-400 mr-2">
                      {tech.id}
                    </span>
                    <span className="text-xs text-black dark:text-white font-medium">
                      {tech.name}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-gray-500 dark:text-gray-400 ml-2 shrink-0">
                    ×{tech.logCount}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Summary stats */}
      {!noData && (
        <div className="grid grid-cols-3 gap-3 pt-1 border-t border-gray-100 dark:border-gray-800">
          <div className="text-center">
            <div className="text-lg font-bold text-black dark:text-white">{totalTTPs}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">total TTPs</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-black dark:text-white">{activeTactics}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">of 14 tactics</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-black dark:text-white">
              {Math.round((activeTactics / 14) * 100)}%
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">kill chain coverage</div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttackHeatmap;
