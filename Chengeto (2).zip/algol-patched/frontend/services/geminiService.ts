import { GoogleGenAI, Type } from "@google/genai";
import { FirewallLog, ThreatAnalysis, OrganizationalContext, RunningService } from '../types';
import { COMPLIANCE_FRAMEWORKS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

const threatAnalysisSchema = {
  type: Type.OBJECT,
  properties: {
    threatName: {
      type: Type.STRING,
      description: "A concise name for the identified threat (e.g., 'SSH Brute-force Attempt').",
    },
    severity: {
      type: Type.STRING,
      description: "The baseline assessed severity level: 'Critical', 'High', 'Medium', 'Low', or 'Informational'.",
    },
    contextualSeverity: {
      type: Type.STRING,
      description: "The adaptive severity score, adjusted for the provided organizational context. If no context is provided, this should be the same as the baseline severity.",
    },
    cveId: {
      type: Type.STRING,
      description: "The most relevant CVE ID if applicable (e.g., 'CVE-2023-12345'), otherwise 'N/A'.",
    },
    summary: {
      type: Type.STRING,
      description: "A brief, one-paragraph summary of the threat and its potential impact.",
    },
    mitigation: {
      type: Type.STRING,
      description: "Recommended mitigation steps beyond the firewall's action.",
    },
    firewallActionAnalysis: {
      type: Type.STRING,
      description: "An analysis of how the firewall's action (e.g., 'BLOCKED') handled this specific threat.",
    },
    threatActorDNA: {
      type: Type.OBJECT,
      properties: {
        name: {
          type: Type.STRING,
          description: "The likely threat actor or group (e.g., 'APT28', 'FIN7', 'Unknown', 'Commodity Malware'). Otherwise 'N/A'."
        },
        ttps: {
          type: Type.ARRAY,
          description: "An array of Tactics, Techniques, and Procedures (TTPs). Each TTP must have a description and MITRE ATT&CK ID.",
          items: {
            type: Type.OBJECT,
            properties: {
              technique: { type: Type.STRING, description: "The name of the MITRE ATT&CK technique." },
              id: { type: Type.STRING, description: "The MITRE ATT&CK ID (e.g., 'T1021.001')." }
            },
            required: ['technique', 'id']
          }
        },
        commonTools: {
          type: Type.STRING,
          description: "Tools commonly used by this actor (e.g., 'Metasploit', 'Cobalt Strike', 'Custom Malware')."
        },
        motivation: {
          type: Type.STRING,
          description: "The likely motivation (e.g., 'Financial Gain', 'Espionage', 'Disruption', 'Notoriety')."
        }
      },
      required: ['name', 'ttps', 'commonTools', 'motivation'],
    },
    predictiveAnalysis: {
      type: Type.STRING,
      description: "A forecast of the attacker's likely next steps if this attack had succeeded or as part of the broader campaign.",
    },
    crossDomainCorrelation: {
      type: Type.STRING,
      description: "Potential links between this cyber threat and other domains — geopolitical events, financial fraud, regional campaigns. State 'None apparent' if no correlation exists.",
    },
    complianceImpact: {
      type: Type.STRING,
      description: "Analysis of potential impact on the SPECIFIC compliance frameworks relevant to the organization's country and industry. For Zimbabwe: reference CDPA 2021 (Cybersecurity and Data Protection Act [Chapter 12:07]), RBZ Cybersecurity Directives, and POTRAZ Regulations where applicable. For other countries use their local frameworks. Be specific about which sections or obligations may be triggered.",
    },
    regionalContext: {
      type: Type.STRING,
      description: "Specific context relevant to the African/SADC region or Zimbabwe if applicable. Consider: known threat actors targeting African financial institutions, regional APT campaigns, infrastructure vulnerabilities common in the region, or CERT.ZW advisories. State 'No specific regional context' if not applicable.",
    },
  },
  required: [
    'threatName', 'severity', 'cveId', 'summary', 'mitigation',
    'firewallActionAnalysis', 'threatActorDNA', 'complianceImpact',
    'predictiveAnalysis', 'crossDomainCorrelation', 'contextualSeverity', 'regionalContext'
  ],
};

export const analyzeThreat = async (log: FirewallLog, context: OrganizationalContext | null): Promise<ThreatAnalysis> => {
  const { mispContext, ...logDetails } = log;
  const logString = JSON.stringify(logDetails, null, 2);

  // Build country-specific compliance guidance
  const countryFrameworks = context?.country
    ? (COMPLIANCE_FRAMEWORKS[context.country] || ['General cybersecurity best practices'])
    : [];

  const contextString = context
    ? `
    Organizational Context:
    - Industry: ${context.industry}
    - Primary Country of Operation: ${context.country}
    - Applicable Compliance Frameworks: ${countryFrameworks.join(', ')}
    ${context.country === 'Zimbabwe' ? `
    - IMPORTANT: This organization operates under Zimbabwe's Cybersecurity and Data Protection Act [Chapter 12:07] (CDPA 2021), enacted by the Government of Zimbabwe. 
    - The CDPA 2021 establishes data protection obligations, cybersecurity requirements, and incident reporting duties.
    - The regulatory authority is POTRAZ (Postal and Telecommunications Regulatory Authority of Zimbabwe).
    - Financial sector organizations are also subject to Reserve Bank of Zimbabwe (RBZ) cybersecurity directives.
    - Critical infrastructure incidents may require reporting to CERT.ZW.
    ` : ''}
    ` : "No organizational context provided.";

  const mispContextString = mispContext
    ? `
    External Threat Intelligence (from MISP / Regional Feeds):
    ${JSON.stringify(mispContext, null, 2)}
    **Crucially, this external intelligence confirms the indicator is known. Correlate this with the log data.**
    ` : "No external intelligence was found for this indicator.";

  const prompt = `
    As a senior cybersecurity analyst named Algol, provide an expert-level, multi-faceted threat analysis of the following firewall log.
    
    ${contextString}
    ${mispContextString}

    Firewall Log:
    ${logString}
    
    Your analysis must be comprehensive and structured. Populate all fields in the requested JSON format.
    
    **Analysis Dimensions:**
    1. **Baseline Identification**: Name the threat, identify relevant CVEs, and determine a baseline severity.
    2. **Adaptive Scoring**: Based on the provided Organizational Context, determine an Adaptive Severity Score. A data exfiltration attempt is more critical for a 'Banking & Financial Services' company in 'Zimbabwe' (CDPA 2021 + RBZ obligations) than for a personal blog.
    3. **Threat Actor DNA**: Profile the likely threat actor with MITRE ATT&CK TTPs, tools, and motivations.
    4. **Predictive Intelligence**: What would the attacker do next?
    5. **Cross-Domain Correlation**: Consider geopolitical context, regional campaigns targeting Africa/SADC, and broader threat patterns.
    6. **Regional Context**: Specifically consider the African/SADC threat landscape. Are there known threat actors targeting this region? Any CERT.ZW or AfricaCERT advisories relevant to this attack pattern?
    7. **Compliance Impact**: Reference the SPECIFIC frameworks for the organization's country — especially Zimbabwe's CDPA 2021 if applicable. Identify which specific obligations or sections may be triggered by this event.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: threatAnalysisSchema,
      },
    });

    const jsonText = response.text.trim();
    const parsedJson = JSON.parse(jsonText);

    if (
      !parsedJson.threatName ||
      !parsedJson.severity ||
      !parsedJson.threatActorDNA?.name ||
      !Array.isArray(parsedJson.threatActorDNA?.ttps)
    ) {
      throw new Error("Invalid response structure from the AI model.");
    }

    return parsedJson as ThreatAnalysis;
  } catch (error) {
    console.error("Error calling AI API:", error);
    if (error instanceof Error && error.message.includes('JSON')) {
      throw new Error("Algol returned a malformed JSON. The model may be unable to generate a valid analysis for this log.");
    }
    throw new Error("Failed to parse threat analysis from Algol.");
  }
};

export const getRemediationSuggestion = async (service: RunningService): Promise<string> => {
  const prompt = `
    As a senior cybersecurity engineer, provide clear, actionable, step-by-step remediation advice for the following insecure service running on an internal device. The advice should be practical for a system administrator to follow.

    Vulnerable Service Details:
    - Service Name: ${service.name}
    - Port: ${service.port}/${service.protocol}
    - Version: ${service.version}
    - Reason for Insecurity: ${service.insecurityReason}

    Format your response as a markdown-formatted string with a clear heading, a brief explanation of the risk, and a numbered list of remediation steps. For example:

    ### Remediation Plan for ${service.name} on Port ${service.port}

    **Risk Overview:** The current configuration is insecure because...

    **Remediation Steps:**
    1. First step...
    2. Second step...
    3. Third step, which might involve a configuration change or patch.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling AI API for remediation:", error);
    throw new Error("Failed to generate remediation steps from Algol.");
  }
};
