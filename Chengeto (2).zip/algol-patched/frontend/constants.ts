import { FirewallLog } from './types';

export const MOCK_LOGS: FirewallLog[] = [];

// ── Geolocation database ────────────────────────────────────────────────────
export const IP_GEOLOCATIONS: Record<string, { lat: number; lng: number; city: string; }> = {
  '198.51.100.54':  { lat: 34.0522,   lng: -118.2437, city: 'Los Angeles, USA' },
  '192.0.2.14':    { lat: 52.3676,   lng: 4.9041,    city: 'Amsterdam, NL' },
  '198.51.100.89': { lat: 51.5074,   lng: -0.1278,   city: 'London, UK' },
  '192.0.2.77':    { lat: 35.6895,   lng: 139.6917,  city: 'Tokyo, JP' },
  '198.51.100.112':{ lat: 40.7128,   lng: -74.0060,  city: 'New York, USA' },
  '192.0.2.199':   { lat: -33.8688,  lng: 151.2093,  city: 'Sydney, AU' },
  '198.51.100.201':{ lat: 48.8566,   lng: 2.3522,    city: 'Paris, FR' },
  '203.0.113.88':  { lat: 55.7558,   lng: 37.6173,   city: 'Moscow, RU' },
  '192.0.2.210':   { lat: 39.9042,   lng: 116.4074,  city: 'Beijing, CN' },
  '203.0.113.42':  { lat: 28.6139,   lng: 77.2090,   city: 'New Delhi, IN' },
  '203.0.113.111': { lat: 4.860,     lng: -1.880,    city: 'Axim, GH' },
  '185.220.101.45':{ lat: 50.1109,   lng: 8.6821,    city: 'Frankfurt, DE (Tor Exit)' },
  '194.165.16.11': { lat: 55.7558,   lng: 37.6173,   city: 'Moscow, RU (APT)' },
  '91.92.109.44':  { lat: 48.2082,   lng: 16.3738,   city: 'Vienna, AT (APT Proxy)' },
  '89.248.167.131':{ lat: 52.3676,   lng: 4.9041,    city: 'Amsterdam, NL (Scanner)' },
  '45.155.205.233':{ lat: 37.5665,   lng: 126.9780,  city: 'Seoul, KR (C2)' },
  '41.78.96.1':    { lat: -17.8252,  lng: 31.0335,   city: 'Harare, ZW' },
  '41.78.96.10':   { lat: -17.8252,  lng: 31.0335,   city: 'Harare, ZW' },
  '41.78.97.1':    { lat: -17.8292,  lng: 31.0522,   city: 'Harare, ZW (CBD)' },
  '41.57.96.1':    { lat: -17.8252,  lng: 31.0335,   city: 'Harare, ZW (NetOne)' },
  '41.57.97.1':    { lat: -17.8252,  lng: 31.0335,   city: 'Harare, ZW (Econet)' },
  '196.13.128.1':  { lat: -17.8636,  lng: 31.0586,   city: 'Harare, ZW (TelOne)' },
  '196.43.128.1':  { lat: -17.8252,  lng: 31.0335,   city: 'Harare, ZW (ZOL)' },
  '41.78.112.1':   { lat: -20.1500,  lng: 28.5833,   city: 'Bulawayo, ZW' },
  '41.78.128.1':   { lat: -19.4500,  lng: 29.8167,   city: 'Gweru, ZW' },
  '41.78.144.1':   { lat: -18.9667,  lng: 32.6500,   city: 'Mutare, ZW' },
  '41.78.176.1':   { lat: -20.0750,  lng: 30.8333,   city: 'Masvingo, ZW' },
  '196.207.0.1':   { lat: -25.7479,  lng: 28.2293,   city: 'Pretoria, ZA' },
  '196.216.0.1':   { lat: -26.2041,  lng: 28.0473,   city: 'Johannesburg, ZA' },
  '196.0.0.1':     { lat: -15.4167,  lng: 28.2833,   city: 'Lusaka, ZM' },
  '196.64.0.1':    { lat: -6.1736,   lng: 35.7394,   city: 'Dodoma, TZ' },
  '196.11.0.1':    { lat: -25.9667,  lng: 32.5833,   city: 'Maputo, MZ' },
  '196.201.0.1':   { lat: -1.2921,   lng: 36.8219,   city: 'Nairobi, KE' },
  '196.168.0.1':   { lat: 6.5244,    lng: 3.3792,    city: 'Lagos, NG' },
};

export const INDUSTRIES = [
  'Banking & Financial Services',
  'Government & Public Sector',
  'Telecommunications',
  'Mining & Resources',
  'Healthcare',
  'Education & Universities',
  'Energy & Utilities',
  'Retail & E-Commerce',
  'Technology & IT Services',
  'NGO & Non-Profit',
  'Legal & Professional Services',
  'Manufacturing',
];

export const COUNTRIES = [
  'Zimbabwe',
  'South Africa',
  'Zambia',
  'Botswana',
  'Mozambique',
  'Tanzania',
  'Kenya',
  'Nigeria',
  'Ghana',
  'USA',
  'United Kingdom',
  'Germany',
  'Japan',
  'Australia',
  'Canada',
  'Singapore',
  'India',
];

export const COMPLIANCE_FRAMEWORKS: Record<string, string[]> = {
  'Zimbabwe':      ['CDPA 2021 (Cybersecurity and Data Protection Act)', 'RBZ Cybersecurity Directives', 'POTRAZ Regulations', 'ZACC Anti-Corruption Guidelines'],
  'South Africa':  ['POPIA', 'ECTA', 'King IV Governance Code'],
  'Zambia':        ['Electronic Communications and Transactions Act', 'Zambia Data Protection Act 2021'],
  'Kenya':         ['Data Protection Act 2019', 'Kenya Information and Communications Act'],
  'Nigeria':       ['NDPR (Nigeria Data Protection Regulation)', 'CBN Cybersecurity Framework'],
  'USA':           ['HIPAA', 'SOX', 'CCPA', 'NIST CSF', 'PCI-DSS'],
  'United Kingdom':['UK GDPR', 'NIS Regulations', 'Cyber Essentials'],
  'Germany':       ['GDPR', 'IT-Sicherheitsgesetz', 'BSI Standards'],
};

export const ZW_THREAT_CONTEXT = {
  certOrg: 'CERT.ZW (Zimbabwe Computer Security Incident Response Team)',
  regulatoryBody: 'POTRAZ (Postal and Telecommunications Regulatory Authority of Zimbabwe)',
  primaryLaw: 'Cybersecurity and Data Protection Act [Chapter 12:07] (CDPA 2021)',
  criticalSectors: ['RBZ (Reserve Bank)', 'ZIMRA (Revenue Authority)', 'NetOne', 'Econet', 'TelOne', 'ZPC (Power)', 'ZINWA (Water)', 'Ministry of Finance'],
};

export const TRAINING_SCENARIO = {
  title: "The Suspicious Data Exfiltration",
  description: "An analyst observes a series of alerts over a 30-minute window. First, a high-volume of DNS queries to a non-standard domain are blocked. Minutes later, a successful TCP connection on port 53 is made to the same IP address resolved from the DNS queries. Finally, a large outbound data transfer is blocked from an internal database server to this external IP.",
  expertAnalysis: "This pattern is highly indicative of DNS Tunneling. The attacker uses DNS queries not for resolution, but to encode and exfiltrate data, bypassing standard firewall rules that might block large outbound transfers on typical HTTP/FTP ports. The successful TCP connection on port 53 (typically UDP for DNS queries) was likely the command-and-control channel. The firewall correctly blocked the final, large data transfer. This is likely a sophisticated attacker attempting data theft."
};
