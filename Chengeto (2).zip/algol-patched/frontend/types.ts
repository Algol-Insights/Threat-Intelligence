export interface FirewallLog {
  id: string;
  timestamp: string;
  sourceIp: string;
  destinationIp: string;
  destinationPort: number;
  protocol: 'TCP' | 'UDP' | 'ICMP';
  action: 'BLOCKED' | 'ALLOWED';
  description: string;
  mispContext?: any; // For future MISP integration
}

export enum Severity {
  Critical = 'Critical',
  High = 'High',
  Medium = 'Medium',
  Low = 'Low',
  Informational = 'Informational',
}

export interface ThreatAnalysis {
  threatName: string;
  severity: Severity;
  contextualSeverity?: Severity;
  cveId: string;
  summary: string;
  mitigation: string;
  firewallActionAnalysis: string;
  threatActorDNA: {
    name: string;
    ttps: { technique: string; id: string; }[]; // Tactics, Techniques, and Procedures
    commonTools: string;
    motivation: string;
  };
  predictiveAnalysis: string;
  crossDomainCorrelation: string;
  complianceImpact: string;
  regionalContext?: string; // Africa/SADC/Zimbabwe-specific threat context
}

export interface GeolocatedThreat extends FirewallLog {
  lat: number;
  lng: number;
  city: string;
}

export interface Alert {
    id: string;
    message: string;
    timestamp: string;
    logId: string;
}

export interface OrganizationalContext {
  industry: string;
  country: string;
}

// Types for Network Monitoring
export enum DeviceType {
  Server = 'Server',
  Workstation = 'Workstation',
  Mobile = 'Mobile',
}

export interface RunningService {
  id: string;
  name: string;
  port: number;
  protocol: 'TCP' | 'UDP';
  version: string;
  status: 'Running';
  isInsecure: boolean;
  insecurityReason?: string;
}

export interface NetworkDevice {
  id: string;
  ipAddress: string;
  hostname: string;
  macAddress: string;
  type: DeviceType;
  status: 'Online' | 'Offline';
  services: RunningService[];
}

// ── Live Metrics (Research Dashboard) ──────────────────────────────────────
export interface AnalysisRecord {
  logId: string;
  startedAt: number;       // ms timestamp when analysis was requested
  completedAt: number;     // ms timestamp when result returned
  latencyMs: number;       // completedAt - startedAt
  severity: Severity;
  contextualSeverity?: Severity;
  wasEnriched: boolean;    // had Africa TI enrichment
}

export interface LiveMetrics {
  totalEvents: number;
  blockedCount: number;
  analyzedCount: number;
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  avgLatencyMs: number;     // mean AI analysis time
  minLatencyMs: number;
  maxLatencyMs: number;
  falsePositiveRate: number; // % of analyzed flagged Low/Info
  mttdMs: number;           // mean time to detect (log ingestion → WebSocket arrival)
  threatsPerMinute: number;
  enrichedCount: number;    // logs enriched by Africa TI
  analysisHistory: AnalysisRecord[];
}