# Algol-Insights — Demo Mode
## UZ Research Week Presentation Tool

This folder contains everything needed to run a **live, staged attack simulation**
that flows real events through the Algol-Insights pipeline — in front of an audience.

---

## Files

| File | Purpose |
|---|---|
| `demo-runner.js` | Sends UDP syslog events + hosts the controller UI |
| `controller.html` | Served automatically at `http://localhost:3002` |

---

## Quick Start (Local)

```bash
# From the demo/ folder:
node demo-runner.js
```

Then open your browser to:
```
http://localhost:3002
```

---

## Quick Start (VPS / Remote Server)

If Algol-Insights is running on a remote server, tell the demo runner where to send events:

```bash
SYSLOG_HOST=YOUR_SERVER_IP node demo-runner.js
```

Then open the controller from any device on the same network:
```
http://localhost:3002
```

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `SYSLOG_HOST` | `127.0.0.1` | IP of the Algol-Insights syslog server |
| `SYSLOG_PORT` | `5514` | UDP syslog port |
| `CONTROL_PORT` | `3002` | Port for the controller web UI |

---

## Scenarios

### 1. Operation Bank Strike (~45s)
**Target:** Zimbabwean commercial bank
**Story:** Port scan → SSH brute-force → successful breach → lateral movement to DB server → 2.3GB data exfiltration → C2 beacon → Algol-Insights auto-block.

**Best for:** Showing the full detection-to-response pipeline.

---

### 2. Ministry Portal Breach (~35s)
**Target:** Government ministry web portal
**Story:** Web enumeration → SQL injection → authentication bypass → classified document downloads → privilege escalation attempt → Algol-Insights incident raised.

**Best for:** Government / Minister of ICT audience — direct relevance.

---

### 3. Telecom Infrastructure Probe (~40s)
**Target:** National telecom operator
**Story:** ICMP network sweep → VoIP infrastructure scan → BGP route manipulation attempt → DNS tunneling/exfiltration → Algol-Insights raises APT alert + notifies CERT.ZW.

**Best for:** Showing nation-state threat detection and telecom sector relevance.

---

## Presentation Tips

1. **Open two screens:** Algol-Insights dashboard on the main projector, Controller UI on your laptop.
2. **Rehearse once** before the event to confirm the pipeline is receiving events.
3. **Start with Scenario 2 (Ministry Breach)** if presenting to the Minister of ICT — most relatable.
4. **Pause after each event phase** to explain what the audience is seeing in the dashboard.
5. The Controller shows a live severity log as events are injected — point to this as your "story".

---

## Troubleshooting

**Events not appearing in dashboard?**
- Check Algol-Insights syslog server is running: `ss -ulnp | grep 5514`
- Verify `SYSLOG_HOST` is set correctly
- Check firewall: `ufw status` (UDP 5514 must be allowed)

**"demo-runner.js not detected" in controller?**
- Make sure `node demo-runner.js` is running in a separate terminal
- Controller connects to `localhost:3002` — they must be on the same machine

---

## Requirements

- Node.js 16+ (no npm install needed — uses built-in `dgram` and `http` modules only)
